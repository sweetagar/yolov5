import torch
import argparse
import math
import numpy as np
from torch.nn.parameter import Parameter
from torch.nn import init

from ingenic_magik_trainingkit.QuantizationTrainingPlugin.python.quantize_ops import *


class LSTMUntilFunction(torch.autograd.Function):
    @staticmethod
    @parse_args('v', 'v', 'v', 'v', 'v', 'v', 'is', 'is', 'i', 'i', 'i', 'i')
    def symbolic(g, input, weights, bias, old_h, old_cell, wscale, quantize,
                 is_fixpoint, input_bitwidth, weight_bitwidth, output_bitwidth,
                 target_device):
        args = [input, weights, bias, old_h, old_cell, wscale]
        kwargs = {
            "quantize_i": quantize,
            "is_fixpoint_i": is_fixpoint,
            "input_bitwidth_i": input_bitwidth,
            "weight_bitwidth_i": weight_bitwidth,
            "output_bitwidth_i": output_bitwidth,
            "target_device_s": target_device
        }
        return g.op("LSTMUntilFunction", *args, **kwargs)

    @staticmethod
    def forward(ctx, input, weights, bias, old_h, old_cell, wscale, quantize,
                is_fixpoint, input_bitwidth, weight_bitwidth, output_bitwidth,
                target_device):
        ctx.quantize_ = quantize
        ctx.input_bitwidth = input_bitwidth
        ctx.weight_bitwidth = weight_bitwidth
        ctx.output_bitwidth = output_bitwidth
        ctx.target_device = target_device
        if not input.is_contiguous():
            input = input.contiguous()
        outputs = imtk_qtp.lstm_forward(quantize, input, weights, bias, old_h,
                                        old_cell, wscale, is_fixpoint,
                                        input_bitwidth, weight_bitwidth,
                                        output_bitwidth, target_device)
        new_h, new_cell = outputs[:2]
        variables = [old_cell] + outputs[1:] + [weights]
        ctx.save_for_backward(*variables)
        res = torch.cat([new_h, new_cell], dim=0)
        return res

    @staticmethod
    def backward(ctx, res_grad):
        old_cell, new_cell, X, gates, weights = ctx.saved_variables
        grad_h, grad_cell = res_grad[0:old_cell.shape[0], :], res_grad[
            old_cell.shape[0]:, :]
        outputs = imtk_qtp.lstm_backward(grad_h.contiguous(),
                                         grad_cell.contiguous(),
                                         *ctx.saved_variables, ctx.quantize_,
                                         ctx.input_bitwidth,
                                         ctx.weight_bitwidth,
                                         ctx.output_bitwidth,
                                         ctx.target_device)
        d_old_h, d_input, d_weights, d_bias, d_old_cell, d_gates = outputs
        return d_input, d_weights, d_bias, d_old_h, d_old_cell, None, None, None, None, None, None, None


class LSTMUntil(torch.nn.Module):
    def __init__(self,
                 quantize=False,
                 input_bitwidth=32,
                 weight_bitwidth=32,
                 output_bitwidth=32,
                 target_device="Txx"):
        super(LSTMUntil, self).__init__()
        self.quantize = quantize
        self.target_device = target_device
        self.input_bitwidth = input_bitwidth
        self.weight_bitwidth = weight_bitwidth
        self.output_bitwidth = output_bitwidth

    def forward(self, input, weights, bias, h, c, wscale, is_fixpoint):
        res = LSTMUntilFunction.apply(input, weights, bias, h, c, wscale,
                                      self.quantize, is_fixpoint,
                                      self.input_bitwidth,
                                      self.weight_bitwidth,
                                      self.output_bitwidth, self.target_device)
        h1, c1 = res[0:h.shape[0], :], res[h.shape[0]:, :]
        return h1, c1


class LSTM_Txx(torch.nn.Module):
    __constants__ = [
        'input_size', 'hidden_size', 'num_layers', 'bias', 'bidirectional'
    ]

    def __init__(self,
                 input_size,
                 hidden_size,
                 num_layers=1,
                 bias=True,
                 bidirectional=False,
                 return_output_states=False,
                 batch_first=True,
                 use_squeeze=False,
                 quantize=False,
                 input_bitwidth=32,
                 weight_bitwidth=32,
                 output_bitwidth=32,
                 weight_factor=3.0,
                 target_device="Txx",
                 is_fixpoint=True):
        super(LSTM_Txx, self).__init__()
        self.mode = "LSTM"
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bias = bias
        self.bidirectional = bidirectional
        self.batch_first = batch_first
        self.use_squeeze = use_squeeze
        num_directions = 2 if bidirectional else 1
        self.quantize = quantize
        self.input_bitwidth = input_bitwidth
        self.weight_bitwidth = weight_bitwidth
        self.output_bitwidth = output_bitwidth
        self.target_device = target_device
        self.weight_factor = weight_factor
        self.return_output_states = return_output_states
        self.is_fixpoint = is_fixpoint
        self.qweight = QuantizeWeight(weight_bitwidth=self.weight_bitwidth,
                                      factor=self.weight_factor,
                                      target_device=self.target_device)
        self.lstm_until_func = LSTMUntil(quantize, input_bitwidth,
                                         weight_bitwidth, output_bitwidth,
                                         target_device)

        gate_size = 4 * hidden_size
        self._flat_weights_names = []
        self._all_weights = []
        for layer in range(num_layers):
            for direction in range(num_directions):
                layer_input_size = input_size if layer == 0 else hidden_size * num_directions

                w = Parameter(
                    torch.Tensor(gate_size, layer_input_size + hidden_size))
                b = Parameter(torch.Tensor(gate_size))
                layer_params = (w, b)
                suffix = '_reverse' if direction == 1 else ''
                param_names = ['weight_l{}{}']
                if bias:
                    param_names += ['bias_l{}{}']

                param_names = [x.format(layer, suffix) for x in param_names]
                for name, param in zip(param_names, layer_params):
                    setattr(self, name, param)
                self._flat_weights_names.extend(param_names)
                self._all_weights.append(param_names)

        self._flat_weights = [(lambda wn: getattr(self, wn)
                               if hasattr(self, wn) else None)(wn)
                              for wn in self._flat_weights_names]
        self.flatten_parameters()
        self.reset_parameters()

    def flatten_parameters(self):
        if len(self._flat_weights) != len(self._flat_weights_names):
            return
        for w in self._flat_weights:
            if not torch.is_tensor(w):
                return
        first_fw = self._flat_weights[0]
        dtype = first_fw.dtype
        for fw in self._flat_weights:
            if (not torch.is_tensor(fw.data) or not (fw.data.dtype == dtype)
                    or not fw.data.is_cuda
                    or not torch.backends.cudnn.is_acceptable(fw.data)):
                return
        unique_data_ptrs = set(p.data_ptr() for p in self._flat_weights)
        if len(unique_data_ptrs) != len(self._flat_weights):
            return

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            init.uniform_(weight, -stdv, stdv)

    def all_weights(self):
        return [[getattr(self, weight) for weight in weights]
                for weights in self._all_weights]

    def forward(self, x):
        if isinstance(x, tuple):
            input = x[0]
            self.lstm_until_func.input_bitwidth = x[1]
        else:
            input = x

        if not self.training:
            op_attr = '{"op_type":"LSTM","attr":{"input_bitwidth":%d,"weight_bitwidth":%d,"output_bitwidth":%d,"weight_factor":%f}}' % (
                self.lstm_until_func.input_bitwidth,
                self.lstm_until_func.weight_bitwidth,
                self.lstm_until_func.output_bitwidth, self.weight_factor)
            self.n_op_start = NOp("lstm_start", op_attr, self.target_device)
            input = self.n_op_start(input)
        if self.use_squeeze:
            input = input.squeeze(axis=2)  #squeeze H
            input = input.permute((0, 2, 1))  # (NTC)(batch, width, channel)

        hx = torch.zeros(input.shape[0],
                         self.hidden_size,
                         dtype=input.dtype,
                         device=input.device)
        hx_ = torch.full((input.shape[0], self.hidden_size),
                         -1.0,
                         dtype=input.dtype,
                         device=input.device)
        if self.target_device in ["Txx", "Xs1", "Xs2"]:
            h0, c0 = (hx, hx)
        else:
            h0, c0 = (hx_, hx_)
        all_weights = self.all_weights()

        def call(x, weight, bias, h, c, wscale, is_fixpoint):
            h_next, c_next1 = self.lstm_until_func(x, weight, bias, h, c,
                                                   wscale, is_fixpoint)
            return h_next, c_next1

        h00 = torch.zeros(input.shape[0], input.shape[1],
                          self.hidden_size).to(input.device)
        h11 = torch.zeros(input.shape[0], input.shape[1],
                          self.hidden_size).to(input.device)

        weight = all_weights[0][0]
        bias = all_weights[0][1]

        wscale = torch.zeros(weight.shape[0], device=weight.device)
        if self.quantize and self.weight_bitwidth != 32:
            weight, wscale = self.qweight([weight, wscale])

        for i in range(input.shape[1]):
            h0, c0 = call(input[:, i, :], weight, bias, h0, c0, wscale,
                          self.is_fixpoint)
            h00[:, i, :] = h0

        if self.bidirectional:
            if self.target_device in ["Txx", "Xs1", "Xs2"]:
                h1, c1 = (hx, hx)
            else:
                h1, c1 = (hx_, hx_)
            weight = all_weights[1][0]
            bias = all_weights[1][1]
            wscale = torch.zeros(weight.shape[0], device=weight.device)
            if self.quantize and self.weight_bitwidth != 32:
                weight, wscale = self.qweight([weight, wscale])
            for i in reversed(range(input.shape[1])):
                h1, c1 = call(input[:, i, :], weight, bias, h1, c1, wscale,
                              self.is_fixpoint)
                h11[:, i, :] = h1
            output = torch.cat([h00, h11], axis=2)
            h_next = torch.stack([h0, h1], axis=0)
            c_next = torch.stack([c0, c1], axis=0)
        else:
            output = h00
            h_next = h0
            c_next = c0
        if not self.training:
            self.n_op_end = NOp("lstm_end", op_attr, self.target_device)
            output = self.n_op_end(output)

        if (self.return_output_states):
            return (output, self.output_bitwidth, -1.), (h_next, c_next)
        return (output, self.output_bitwidth, -1.), h_next
