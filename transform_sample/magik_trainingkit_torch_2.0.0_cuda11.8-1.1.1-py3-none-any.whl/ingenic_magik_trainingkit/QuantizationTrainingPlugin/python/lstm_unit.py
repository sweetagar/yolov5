import torch
import json
import argparse
import math
import numpy as np
from torch.nn.parameter import Parameter
from torch.nn import init

from ingenic_magik_trainingkit.QuantizationTrainingPlugin.python.quantize_ops import *

class lstm_returns:
    def __init__(self) -> None:
        self.output = torch.tensor()

def flip(x, dim):
    indices = [slice(None)] * x.dim()
    indices[dim] = torch.arange(x.size(dim) - 1, -1, -1,
                                dtype=torch.long, device=x.device)
    return x[tuple(indices)]

class QuantizeLSTMV2(torch.autograd.Function):
    @staticmethod
    @parse_args('v', 'v', 'v', 'v', 'v', 'v', 'v', 'v', 'v', 'i', 'i', 'is', 'is', 'is', 'is', 'i', 'i', 'i', 'i')
    def symbolic(g,
                 input, fw_weight, bw_weight, fw_bias, bw_bias, old_h, old_cell, fw_wscale, bw_wscale,
                 num_layers, hidden_size,
                 bidirectional, batch_first, quantize, is_fixpoint,
                 input_bitwidth, weight_bitwidth, output_bitwidth,
                 target_device):
        kwargs = {
                "quantize_i": quantize,
                "input_bitwidth_i": input_bitwidth,
                "batch_first_i": batch_first,
                "num_layers_i": num_layers,
                "hidden_size_i": hidden_size,
                "is_fixpoint_i": is_fixpoint,
                "weight_bitwidth_i": weight_bitwidth,
                "output_bitwidth_i": output_bitwidth,
                "clip_min_value_f": -6.0,
                "clip_max_value_f": 6.0,
                "target_device_s": target_device,
                "quantize_feature_version_i": int(1002),
                "layout_i": 1
            }
        if bidirectional:
            kwargs["direction_s"] = "bidirectional"
        else:
            kwargs["direction_s"] = "forward"
        if not bidirectional:
            args = [input, fw_weight, fw_bias, old_h, old_cell]
        else:
            args = [input, fw_weight, bw_weight, fw_bias, bw_bias, old_h, old_cell]

        return g.op("QuantizeLSTMV2", *args, **kwargs, outputs=3)

    @staticmethod
    def forward(ctx, input, fw_weight, bw_weight, fw_bias, bw_bias, old_h, old_cell, fw_wscale, bw_wscale,
                 num_layers, hidden_size, bidirectional, batch_first, quantize, is_fixpoint,
                 input_bitwidth, weight_bitwidth, output_bitwidth,
                 target_device):
        ctx.quantize_ = quantize
        ctx.input_bitwidth = input_bitwidth
        ctx.weight_bitwidth = weight_bitwidth
        ctx.output_bitwidth = output_bitwidth
        ctx.target_device = target_device
        ctx.bidirectional = bidirectional
        ctx.batch_first = batch_first
        ctx.num_layers = num_layers
        ctx.hidden_size = hidden_size
        if not input.is_contiguous():
            input = input.contiguous()
        if not old_h.is_contiguous():
            old_h = old_h.contiguous()
        if not old_cell.is_contiguous():
            old_cell = old_cell.contiguous()
        if not bidirectional:
            outputs = imtk_qtp.lstm_forward_all(quantize, input, fw_weight, fw_bias, old_h[:,0,:],
                                        old_cell[:,0,:], fw_wscale, is_fixpoint,
                                        input_bitwidth, weight_bitwidth,
                                        output_bitwidth, target_device)
            output, new_h, new_cell = outputs[0][0], outputs[1][-1], outputs[2][-1]

            #batch, seq_length, hidden_size ==> B,S,num_directions,H
            output = torch.unsqueeze(output, 2)
            len_size = len(outputs[2])
            old_cells = torch.stack(outputs[2][:len_size-1],0)
            new_cells = torch.stack(outputs[2][1:],0)
            Xs = torch.stack(outputs[3],0)
            gates = torch.stack(outputs[4],0)
            #S,B,num_directions,H => S,B,H
            old_cells = torch.squeeze(old_cells, 2)
            new_cells = torch.squeeze(new_cells, 2)
            variables = [old_cells] + [new_cells] + [Xs] + [gates] + [fw_weight]
            ctx.save_for_backward(*variables)
            return output, new_h, new_cell
        else:
            fw_outputs = imtk_qtp.lstm_forward_all(quantize, input, fw_weight, fw_bias, old_h[:,0,:],
                                        old_cell[:,0,:], fw_wscale, is_fixpoint,
                                        input_bitwidth, weight_bitwidth,
                                        output_bitwidth, target_device)
            fw_output, new_fw_h, new_fw_c = fw_outputs[0][0], fw_outputs[1][-1], fw_outputs[2][-1]
            #batch, seq_length, hidden_size ==> B,S,num_directions,H
            fw_output = torch.unsqueeze(fw_output, 2)
            #get history c, history X history gates
            len_size = len(fw_outputs[2])
            old_fw_cells = torch.stack(fw_outputs[2][:len_size-1],0)
            new_fw_cells = torch.stack(fw_outputs[2][1:],0)
            #S,B,num_directions,H => S,B,H
            old_fw_cells = torch.squeeze(old_fw_cells, 2)
            new_fw_cells = torch.squeeze(new_fw_cells, 2)

            fw_Xs = torch.stack(fw_outputs[3],0)
            fw_gates = torch.stack(fw_outputs[4],0)
            #reversed
            reverse_input = flip(input,1)
            bw_outputs = imtk_qtp.lstm_forward_all(quantize, reverse_input, bw_weight, bw_bias, old_h[:,1,:],
                                        old_cell[:,1,:], bw_wscale, is_fixpoint,
                                        input_bitwidth, weight_bitwidth,
                                        output_bitwidth, target_device)
            bw_output, new_bw_h, new_bw_c = bw_outputs[0][0], bw_outputs[1][-1], bw_outputs[2][-1]
            bw_output = flip(bw_output,1)
            #batch, seq_length, hidden_size ==> B,S,num_directions,H
            bw_output = torch.unsqueeze(bw_output, 2)

            len_size = len(bw_outputs[2])
            old_bw_cells = torch.stack(bw_outputs[2][:len_size-1],0)
            new_bw_cells = torch.stack(bw_outputs[2][1:],0)
            #S,B,num_directions,H => S,B,H
            old_bw_cells = torch.squeeze(old_bw_cells, 2)
            new_bw_cells = torch.squeeze(new_bw_cells, 2)
            bw_Xs = torch.stack(bw_outputs[3],0)
            bw_gates = torch.stack(bw_outputs[4],0)

            output = torch.cat([fw_output, bw_output], axis=2)
            h_next = torch.cat([new_fw_h, new_bw_h], axis=1)
            c_next = torch.cat([new_fw_c, new_bw_c], axis=1)

            #save backward variables
            variables = [old_fw_cells] + [new_fw_cells] + [fw_Xs] + [fw_gates] + [fw_weight] + \
                        [old_bw_cells] + [new_bw_cells] + [bw_Xs] + [bw_gates] + [bw_weight]
            ctx.save_for_backward(*variables)
            return output, h_next, c_next
    @staticmethod
    def backward(ctx, grad_output, grad_h, grad_cell):
        if not ctx.bidirectional:
            #grad_output =>(batch, seq_l, num_directions, hidden_size)
            #grad_h => (batch, num_directions, hidden_size)
            grad_output = grad_output[:,:,0,:] #get forward =>(batch, seq_l, hidden_size)
            grad_h = grad_h[:,0,:] #(batch, hidden_size)
            grad_cell = grad_cell[:,0,:]
            outputs = imtk_qtp.lstm_backward_all(grad_output.contiguous(),
                                         grad_h.contiguous(),
                                         grad_cell.contiguous(),
                                         *ctx.saved_variables,
                                         ctx.quantize_,
                                         ctx.input_bitwidth,
                                         ctx.weight_bitwidth,
                                         ctx.output_bitwidth,
                                         ctx.target_device)
            d_old_h, d_input, d_fw_weights, d_fw_bias, d_old_cell = outputs

            return d_input, d_fw_weights, None, d_fw_bias, None, d_old_h, d_old_cell, None, None, None, None, None, None, None, None, None ,None, None ,None
        else:
            #ctx.saved_variables[:5] fw_save variables
            #ctx.saved_variables[5:] bw_save variables
            fw_grad_output, bw_grad_output = grad_output[:,:,0,:], grad_output[:,:,1,:]
            fw_grad_h, bw_grad_h = grad_h[:,0,:], grad_h[:,1,:]
            fw_grad_c, bw_grad_c = grad_cell[:,0,:], grad_cell[:,1,:]

            fw_outputs = imtk_qtp.lstm_backward_all(fw_grad_output.contiguous(),
                                         fw_grad_h.contiguous(),
                                         fw_grad_c.contiguous(),
                                         *ctx.saved_variables[:5],
                                         ctx.quantize_,
                                         ctx.input_bitwidth,
                                         ctx.weight_bitwidth,
                                         ctx.output_bitwidth,
                                         ctx.target_device)
            d_old_fw_h, d_fw_input, d_fw_weights, d_fw_bias, d_old_fw_cell = fw_outputs

            bw_grad_output = flip(bw_grad_output,1) # grad  reverse
            bw_outputs = imtk_qtp.lstm_backward_all(bw_grad_output.contiguous(),
                                         bw_grad_h.contiguous(),
                                         bw_grad_c.contiguous(),
                                         *ctx.saved_variables[5:],
                                         ctx.quantize_,
                                         ctx.input_bitwidth,
                                         ctx.weight_bitwidth,
                                         ctx.output_bitwidth,
                                         ctx.target_device)
            d_old_bw_h, d_bw_input, d_bw_weights, d_bw_bias, d_old_bw_cell = bw_outputs
            d_bw_input = flip(d_bw_input,1)

            d_old_fw_h = torch.unsqueeze(d_old_fw_h, 0)
            d_old_fw_cell = torch.unsqueeze(d_old_fw_cell, 0)
            d_old_bw_h = torch.unsqueeze(d_old_bw_h, 0)
            d_old_bw_cell = torch.unsqueeze(d_old_bw_cell, 0)
            d_input = d_bw_input + d_fw_input

            d_old_h = torch.cat([d_old_fw_h, d_old_bw_h], axis=0)
            d_old_cell = torch.cat([d_old_fw_cell, d_old_bw_cell], axis=0)

            return d_input, d_fw_weights, d_bw_weights, d_fw_bias, d_bw_bias, d_old_h, d_old_cell, None, None, None, None, None, None, None, None, None, None, None ,None

class LSTMUntil(torch.nn.Module):
    def __init__(self,
                 hidden_size,
                 batch_first = True,
                 num_layers = 1,
                 quantize=False,
                 input_bitwidth=32,
                 weight_bitwidth=32,
                 output_bitwidth=32,
                 target_device="Txx"):
        super(LSTMUntil, self).__init__()
        self.batch_first = batch_first
        self.num_layers = num_layers
        self.hidden_size = hidden_size
        self.quantize = quantize
        self.target_device = target_device
        self.input_bitwidth = input_bitwidth
        self.weight_bitwidth = weight_bitwidth
        self.output_bitwidth = output_bitwidth

    def forward(self, input, bidirectional, fw_weight, bw_weight, fw_bias, bw_bias, hx, fw_wscale, bw_wscale, is_fixpoint):
        output, h1, c1 = QuantizeLSTMV2.apply(input,
                                 fw_weight, bw_weight,
                                 fw_bias, bw_bias,
                                 hx[0], hx[1],
                                 fw_wscale, bw_wscale,
                                 self.num_layers,
                                 self.hidden_size,
                                 bidirectional,
                                 self.batch_first,
                                 self.quantize, is_fixpoint,
                                 self.input_bitwidth,
                                 self.weight_bitwidth,
                                 self.output_bitwidth, self.target_device)
        if not bidirectional:
            output = torch.squeeze(output, 2)
        elif bidirectional:
            output = torch.reshape(output,(output.size()[0], output.size()[1], -1))
        return output, h1, c1


class LSTM_(torch.nn.Module):
    __constants__ = [
        'input_size', 'hidden_size', 'num_layers', 'bias', 'bidirectional'
    ]

    def __init__(self,
                 input_size,
                 hidden_size,
                 num_layers=1,
                 bias=True,
                 bidirectional=False,
                 return_output_states=False,
                 batch_first=True,
                 use_squeeze=False,
                 quantize=False,
                 input_bitwidth=32,
                 weight_bitwidth=32,
                 output_bitwidth=32,
                 weight_factor=3.0,
                 target_device="Txx",
                 is_fixpoint=True):
        super(LSTM_, self).__init__()
        self.mode = "LSTM"
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.bias = bias
        self.bidirectional = bidirectional
        self.batch_first = batch_first
        self.use_squeeze = use_squeeze
        self.num_directions = 2 if bidirectional else 1
        self.quantize = quantize
        self.input_bitwidth = input_bitwidth
        self.weight_bitwidth = weight_bitwidth
        self.output_bitwidth = output_bitwidth
        self.target_device = target_device
        self.weight_factor = weight_factor
        self.initial_state_fw = None
        self.initial_state_bw = None
        self.return_output_states = return_output_states
        self.is_fixpoint = is_fixpoint
        self.qweight = QuantizeWeight(weight_bitwidth=self.weight_bitwidth,
                                      factor=self.weight_factor,
                                      target_device=self.target_device)
        self.lstm_until_func = LSTMUntil(self.hidden_size, self.batch_first, self.num_layers, quantize, input_bitwidth,
                                         weight_bitwidth, output_bitwidth,
                                         target_device)

        assert num_layers==1, "num_layers=%d, We only support one layer in LSTM now!"%num_layers
        gate_size = 4 * hidden_size
        self._flat_weights_names = []
        self._all_weights = []

        for layer in range(num_layers):
            for direction in range(self.num_directions):
                layer_input_size = input_size if layer == 0 else hidden_size * self.num_directions
                w = Parameter(
                    torch.Tensor(gate_size, layer_input_size + hidden_size))
                b = Parameter(torch.Tensor(gate_size))
                layer_params = (w, b)
                suffix = '_reverse' if direction == 1 else ''
                param_names = ['weight_l{}{}']
                if bias:
                    param_names += ['bias_l{}{}']

                param_names = [x.format(layer, suffix) for x in param_names]
                for name, param in zip(param_names, layer_params):
                    setattr(self, name, param)
                self._flat_weights_names.extend(param_names)
                self._all_weights.append(param_names)

        self._flat_weights = [(lambda wn: getattr(self, wn)
                               if hasattr(self, wn) else None)(wn)
                              for wn in self._flat_weights_names]
        self.flatten_parameters()
        self.reset_parameters()

    def flatten_parameters(self):
        if len(self._flat_weights) != len(self._flat_weights_names):
            return
        for w in self._flat_weights:
            if not torch.is_tensor(w):
                return
        first_fw = self._flat_weights[0]
        dtype = first_fw.dtype
        for fw in self._flat_weights:
            if (not torch.is_tensor(fw.data) or not (fw.data.dtype == dtype)
                    or not fw.data.is_cuda
                    or not torch.backends.cudnn.is_acceptable(fw.data)):
                return
        unique_data_ptrs = set(p.data_ptr() for p in self._flat_weights)
        if len(unique_data_ptrs) != len(self._flat_weights):
            return

    def reset_parameters(self):
        stdv = 1.0 / math.sqrt(self.hidden_size)
        for weight in self.parameters():
            init.uniform_(weight, -stdv, stdv)

    def all_weights(self):
        return [[getattr(self, weight) for weight in weights]
                for weights in self._all_weights]

    def add_in_nop(self):
        op_attr = {"op_type":"input","attr":"input_index_indexX"}
        op_attr = json.dumps(op_attr)
        n_op_start = NOp("input", op_attr, self.target_device)

        return n_op_start

    def forward(self, x, hx=None):
        if isinstance(x, tuple):
            input = x[0]
            self.lstm_until_func.input_bitwidth = x[1]
        else:
            input = x

        if self.use_squeeze:
            input = input.squeeze(axis=2)  #squeeze H
            input = input.permute((0, 2, 1))  # (NTC)(batch, width, channel)
        max_batch_size = input.size(0) if self.batch_first else input.size(1)
        if hx is None:
            num_directions = 2 if self.bidirectional else 1
            real_hidden_size = self.hidden_size
            h_zeros = torch.zeros(max_batch_size, self.num_layers * num_directions,
                                  real_hidden_size,
                                  dtype=input.dtype, device=input.device)
            c_zeros = torch.zeros(max_batch_size, self.num_layers * num_directions,
                                  self.hidden_size,
                                  dtype=input.dtype, device=input.device)
            if self.target_device in ["Txx", "Xs1", "Xs2"]:
                hx = (h_zeros, c_zeros)
            else:
                hx = (h_zeros - 1, c_zeros - 1)

        #hx ===> Tuple(h ,c)
        all_weights = self.all_weights()

        weight_fw = all_weights[0][0]
        bias_fw = all_weights[0][1]
        wscale_fw = torch.zeros(weight_fw.shape[0], device=weight_fw.device)
        if self.quantize and self.weight_bitwidth != 32:
            weight_fw, wscale_fw = self.qweight([weight_fw, wscale_fw])
        #init
        weight_bw = torch.zeros(1)
        bias_bw = torch.zeros(1)
        wscale_bw = torch.zeros(1)
        if self.bidirectional:
            weight_bw = all_weights[1][0]
            bias_bw = all_weights[1][1]
            wscale_bw = torch.zeros(weight_bw.shape[0], device=weight_bw.device)
            if self.quantize and self.weight_bitwidth != 32:
                weight_bw, wscale_bw = self.qweight([weight_bw, wscale_bw])

        output, h_next, c_next = self.lstm_until_func(input, self.bidirectional,
                                                      weight_fw, weight_bw,
                                                      bias_fw, bias_bw,
                                                      hx,
                                                      wscale_fw, wscale_bw,
                                                      self.is_fixpoint)

        if isinstance(x, tuple):
            if (self.return_output_states):
                return (output, self.output_bitwidth, -1.), (h_next, c_next)
            else:
                return (output, self.output_bitwidth, -1.), h_next
        else:
            if (self.return_output_states):
                return output, (h_next, c_next)
            else:
                return output, h_next
